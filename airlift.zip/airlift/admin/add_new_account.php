<div class="airlift">
	<div id="add-new-account">
		<section id="header">
			<div class="custom-container">
				<?php
					require_once dirname( __FILE__ ) . "/components/header_top.php";
					require_once dirname( __FILE__ ) . "/components/form.php";
				?>
			</div>
		</section>
		<?php
			require_once dirname( __FILE__ ) . "/components/show-secret-key.php";
		?>
	</div>
</div>